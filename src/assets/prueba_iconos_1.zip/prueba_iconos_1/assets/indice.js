Visor.Indice = [""];
function gotoPageIndice(capitulo){
var Pagina=0;
switch (capitulo) {
case '':
Pagina=0;
break;
default:
Pagina=0;
}
return Pagina;
}